/**
	_enyo.ToolDecorator_ lines up components in a row, centered vertically.
*/
enyo.kind({
	name: "enyo.ToolDecorator",
	//* @protected
	kind: enyo.GroupItem,
	classes: "enyo-tool-decorator"
});
